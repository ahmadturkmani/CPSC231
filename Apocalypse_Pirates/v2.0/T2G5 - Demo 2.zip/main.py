#This game is a working Apocalypse game. Designed by The Apocalypse Pirates at The University of Calgary. 
#All work is licensed under the MIT license, unless otherwise noted.
#Images used in the GUI are derived works from public domain work, unless otherwise noted. 
#T2G5 Team Project - Demo 2 Final Rev. 

#Imports
import gui

#Start Game Loop. 
GUI = gui.ApocalypseGUI(960, 720)
